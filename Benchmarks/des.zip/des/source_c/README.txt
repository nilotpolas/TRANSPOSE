Usage:
Compile:gcc testbench_des_level.c des_heir.c -w
Run:	./a.out